@extends('install.games.layout')

@section('game')
    <small class="form-text text-danger">{{ trans('install.game.warn') }}</small>
@endsection
