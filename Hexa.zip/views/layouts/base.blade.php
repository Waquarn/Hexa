<!DOCTYPE html>
@include('elements.base')
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="@yield('description', setting('description', ''))">
    <meta name="theme-color" content="#3490DC">
    <meta name="author" content="Azuriom">

    <meta property="og:title" content="@yield('title')">
    <meta property="og:type" content="@yield('type', 'website')">
    <meta property="og:url" content="{{ url()->current() }}">
    <meta property="og:image" content="{{ favicon() }}">
    <meta property="og:description" content="@yield('description', setting('description', ''))">
    <meta property="og:site_name" content="{{ site_name() }}">
    @stack('meta')

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>@yield('title') | {{ site_name() }}</title>

    <!-- Favicon -->
    <link rel="shortcut icon" href="{{ favicon() }}">

    <!-- Scripts -->
    <script src="{{ asset('vendor/bootstrap/js/bootstrap.bundle.min.js') }}" defer></script>
    <script src="{{ asset('vendor/axios/axios.min.js') }}" defer></script>
    <script src="{{ asset('js/script.js') }}" defer></script>

    <!-- Page level scripts -->
    @stack('scripts')

    <!-- Fonts -->
    <link href="{{ asset('vendor/bootstrap-icons/bootstrap-icons.css') }}" rel="stylesheet">

    <!-- Styles -->
    <link href="{{ asset('vendor/bootstrap/css/bootstrap.min.css') }}" rel="stylesheet">
    @stack('styles')
    <style>
        html,
        body {
            height: 100%;
        }

        body {
            display: flex;
            flex-direction: column;
            background: #292734;
        }

        a {
            text-decoration: none;
        }

        #app {
            flex-shrink: 0;
            background-color: #22222;
        }

        .content {
            margin-top: 3rem;
            margin-bottom: 3rem;
            background: #22222;
        }

        img {
            max-width: 100%;
            height: auto;
        }
footer {
background: rgb(66,66,66);
background: linear-gradient(90deg, rgba(66,66,66,1) 0%, rgba(40,40,40,1) 99%);}
.trutyi {
  width: 100px;
  height: 100px;
  background-image: radial-gradient(circle, #0074d9, #001f3f);
  position: absolute;
  bottom: 70px;
  left: 100px;
  border-radius: 50%;
  transition: scale 1s;
}
.trutyitext {
  width: 100px;
  height: 100px;
  position: absolute;

  left: 100px;
  transition: scale 1s;
}

.trutyi:hover {
  scale: 0.9;
}
.footer-uzenet-copyright {
  transition: color 0.3s;
}
.footer-uzenet-copyright:hover {
  color: #1d80c2;
}
.d-inline-block.mx-1.p-2.rounded-circle {
  width: 4%;
  transition: scale 0.5s;
}
.d-inline-block.mx-1.p-2.rounded-circle:hover {
  scale: 1.07;
}
.logo-container {
  position: absolute;
  right: 20px;
  top: 50%;
  transform: translateY(-50%);
  transition: filter 0.3s ease-in-out;
}

.logo {
  width: 100px;
  height: auto;
}

.logo-container:hover {
  filter: grayscale(100%); 
}
.card.szerverikon {
  width: 300px;
  padding: 20px;
  box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
  border-radius: 10px;
  text-align: center;
  transition: transform 0.3s ease-in-out, opacity 0.3s ease, color 0.3s ease;
}

.card.szerverikon:hover {
  opacity: 0.8;
  transform: translateY(-10px);
}    
.ipcopy {
    border: 2px solid black;
    padding: 10px 20px;
    cursor: pointer;
  transition: scale 0.4s;
}
.ipcopy:hover {
  scale: 0.9;
}
img.profilkep {
  transition: scale 0.2s;
}
img.profilkep:hover {
  scale: 1.05;
}
</style>
</head>

<body>
<div id="app">
    <header>
        @include('elements.navbar')
    </header>

    @yield('app')
</div>

<footer class="text-center text-white bg-dark mt-auto py-4 position-relative re">
    <div class="trutyi"></div>
        <div class="trutyitext">
            <p>A weboldal témát a <a href="https://www.whost.tech" style="color: lightblue;">WHost</a> készítette</p>
        </div>

    <div class="container">
        <div class="logo-container">
            <img src="{{ site_logo() }}" alt="Logo" class="logo">
        </div>
        <p class="footer-uzenet-copyright">{{ setting('copyright') }} | @lang('messages.copyright')</p>

        @foreach(social_links() as $link)
            <a href="{{ $link->value }}" title="{{ $link->title }}" target="_blank" rel="noopener noreferrer"
               data-bs-toggle="tooltip"
               class="d-inline-block mx-1 p-2 rounded-circle" style="background: {{ $link->color }}">
                <i class="{{ $link->icon }} text-white"></i>
            </a>
        @endforeach
    </div>
</footer>

@stack('footer-scripts')
</body>
</html>
