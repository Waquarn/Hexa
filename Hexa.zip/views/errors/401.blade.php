@extends('errors::layout')

@section('title', trans('errors.401.title'))
@section('code', '401')
@section('message', trans('errors.401.message'))
