@extends('errors::layout')

@section('title', trans('errors.500.title'))
@section('code', '500')
@section('message', trans('errors.500.message'))
