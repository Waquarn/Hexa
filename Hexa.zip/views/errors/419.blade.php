@extends('errors::layout')

@section('title', trans('errors.419.title'))
@section('code', '419')
@section('message', trans('errors.419.message'))
