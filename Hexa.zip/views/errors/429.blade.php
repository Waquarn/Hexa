@extends('errors::layout')

@section('title', trans('errors.429.title'))
@section('code', '429')
@section('message', trans('errors.429.message'))
